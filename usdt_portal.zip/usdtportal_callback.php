<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

require_once($_SERVER['DOCUMENT_ROOT']."/load.php");
require_once($_SERVER['DOCUMENT_ROOT']."/language/language.php");
require_once ($_SERVER['DOCUMENT_ROOT']."/gateways/usdt_portal/usdtportal.php");

$elocate = do_format_url('account','invoices');
$gatewayData = $db->where('is_active',1)->where('basename','usdt_portal')->getOne('payment_gateways');
$paymentGateway = sys_check_payment_gateway('usdt_portal');
if(empty($gatewayData) || empty($paymentGateway)) {
  echo "Gateway disabled";
  die();
}

$cridentials = json_decode($gatewayData['options'],true);

// SETUP TESTERS
if (isset($_POST['test_callback'], $_POST['email'], $_POST['callback_url_password'])) {
  if ($cridentials['api_secret_callback_password'] != $_POST['callback_url_password'] || $cridentials['api_email'] != $_POST['email']) {
      $data = [ 
          'is_success' => false,
          'message' => "Credentials no match. Make sure you setup Email, Api Key and Secret Callback Password in your DHRU website from Settings>Payment Gateways>USDT Portal - Auto Crypto Payments"
      ];
      exit(json_encode($data));
  } else {
      $ip = getServerIP();
      $ipv6 = getServerIPv6();
      $data = [ 
          'is_success' => true,
          'message' => "Credentials match. Callback is correctly set.<br>IPv4: $ip<br>IPv6: $ipv6",
          'ip' => $ip,
          'ipv6' => $ipv6
      ];
      exit(json_encode($data));
  }
}



// PAYMENT CALLBACK PART
if (!isset($_POST['order_id'], $_POST['transaction_id'], $_POST['amount_with_commission'], $_POST['fee'], $_POST['user_email'], $_POST['txn_hash'], $_POST['received_timestamp'], $_POST['email'], $_POST['callback_url_password'])) {
  exit("What are you doing here?");
}

if($cridentials['api_secret_callback_password'] != $_POST['callback_url_password'] || $cridentials['api_email'] != $_POST['email'])
{
    $data = [ 
    'is_success' => false,
    'message' => "Credentials no match"
    ];
    exit(json_encode($data));
}

$order_id = $_POST['order_id'];
$transaction_id = $_POST['transaction_id'];
$user_email = $_POST['user_email'];
$amount = $_POST['amount'];
$amount_with_commission = $_POST['amount_with_commission'];
$fee = $_POST['fee'];
$currency = $_POST['currency'];
$network = $_POST['network'];
$target_wallet = $_POST['target_wallet'];
$txn_hash = $_POST['txn_hash'];
$initiated_timestamp = $_POST['initiated_timestamp'];
$received_timestamp = $_POST['received_timestamp'];
$status = $_POST['status'];
$creation_ip = $_POST['creation_ip'];



$gatewayData['options'] = !empty($gatewayData['options'])? json_decode($gatewayData['options'],true) : [];
$paymentGateway['gateway_id'] = round($gatewayData['gateway_id']);
$paymentGateway['options'] = array_merge($paymentGateway['options'],$gatewayData['options']);
$paymentGateway['is_active'] = intval($gatewayData['is_active']);


$invoiceData = $db->where('invoice_id',$order_id)->getOne('invoices');
if(empty($invoiceData)) {
    $data = [ 
        'is_success' => false,
        'message' => 'Invoice not found'
    ];
    exit(json_encode($data));
}
$elocate =  do_format_url('account','invoices','invoice',['uid' => $invoiceData['invoice_uid']]);

if ($invoiceData['is_active'] != 0) {
    $data = [ 
        'is_success' => false,
        'message' => 'Invoice already paid'
    ];
    exit(json_encode($data));
}


$usdtportal = new USDT_Portal();
$usdtportal->set_access($cridentials['api_email'], $cridentials['api_key']);
if ($usdtportal->verify_payment($transaction_id)) {
    if (sys_create_transaction($invoiceData['user_id'],$invoiceData['invoice_id'],$paymentGateway['basename'],$transactionID,$invoiceData['due'],$txn_hash,$network)) {
      $data = [ 
          'is_success' => true,
          'message' => "Credits Added - $amount"
      ];
      exit(json_encode($data));
  } else {
      $data = [ 
          'is_success' => false,
          'message' => 'Marking as paid failed'
      ];
      exit(json_encode($data));
  }
} else {
  $data = [ 
    'is_success' => false,
    'message' => 'Payment not done by customer!'
  ];
  exit(json_encode($data));
}





function getServerIP() {
    $ch = curl_init('https://api.ipify.org?format=json');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($response);
    return isset($json->ip) ? $json->ip:'0';
}

function getServerIPv6() {
    $ch = curl_init('https://api64.ipify.org?format=json');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($response);
    return isset($json->ip) ? $json->ip:'0';
}
