<?php
if(! defined('DB_HOST')) exit();

$gateway = array(
	'basename' => 'usdt_portal',
	'title' => 'USDT Portal - www.usdtportal.com/panel',
	'fields' => array(
		'friendly_name' => array('title' => 'Friendly Name','type' => 'text','required' => 1),
		'api_email' => array('title' => 'USDT Portal Account Email','type' => 'text','required' => 1),
		'api_key' => array('title' => 'API Key','type' => 'text','required' => 1, 'no_trim' => 1),
		'api_secret_callback_password' => array('title' => 'Secret Callback Password','type' => 'text','required' => 1),
		'currency_code' => array('title' => 'Currency Code','type' => 'text', 'pattern' => '[a-zA-Z]{3}','required' => 1),
		'currency_rate' => array('title' => 'Currency Rate','type' => 'number','step' => 'any','min' => '0','required' => 1),
	),
	'options' => array(
		'friendly_name' => 'USDT Portal - USDT TRC|ERC|BEP & BinancePay',
		'api_email' => '',
		'api_key' => '',
		'api_secret_callback_password' => '',
		'currency_code' => 'USD',
		'currency_rate' => 1,
	),
	'icon' => 'usdt_portal.png',
	'payment_template' => 'template.html',
);
