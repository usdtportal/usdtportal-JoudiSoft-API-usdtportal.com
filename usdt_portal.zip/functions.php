<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

if(! defined('DB_HOST')) exit();

function gateway_usdt_portal_invoice_precheck($invoice,$user) {
	if(round($invoice['due'],4) <= 0) return false;
	return true;
}

function gateway_usdt_portal_payment_request($payment,$user,$postData) {
	global $__DIR, $_OPTIONS, $_LANGUAGE;
	require_once ($_SERVER['DOCUMENT_ROOT']."/gateways/usdt_portal/usdtportal.php");

	$convertRate = !empty($payment['gateway']['options']['currency_rate'])? round($payment['gateway']['options']['currency_rate'],4) : 1;
	if(!is_numeric($convertRate) || $convertRate === 0) $convertRate = 1;
	$payDue = round(round($payment['invoice']['due'],4) * $convertRate,2);

	try {

		$usdtportal = new USDT_Portal();
		$usdtportal->set_access($payment['gateway']['options']['api_email'], $payment['gateway']['options']['api_key']);
		$usdtportal->set_order($user['email'], $payDue, $payment['invoice']['invoice_id'], "https://".$_SERVER['HTTP_HOST'] . "/?a=account", $payment['invoice']['invoice_url']);

		$new_payment = $usdtportal->generate_link();

		if ($usdtportal->http_code === 403) {
			do_add_notice('Please whitelist your Server IP in USDT Portal Merchant Panel','danger');
			return false;
		}

		if($usdtportal->http_code !== 200) {
			do_add_notice('USDT Portal server is down','danger');
			return false;
		}

		if (!$new_payment->auth || $new_payment->error) {
			do_add_notice($new_payment->message,'danger');
			return false;
		}

		if (isset($new_payment->url)) {
			header("Location: $new_payment->url");
			return false;
		} 

		do_add_notice($_LANGUAGE['notice_payment_unknown_failure'],'danger');
		return false;
	} catch (\Exception $e) {
		do_add_notice($_LANGUAGE['notice_payment_unknown_failure'],'danger');
		return false;
   	}

}
